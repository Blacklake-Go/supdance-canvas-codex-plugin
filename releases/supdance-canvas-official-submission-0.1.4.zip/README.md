# SupDance Canvas for Codex

This plugin package includes its local SupDance Canvas Agent and production
dependencies. Install Node.js 18 or later and the Codex desktop CLI before
using it. The Agent uses the `codex` executable on `PATH`; set `CODEX_CLI_PATH`
if it is installed elsewhere.

Start a new Codex task after installing the plugin so its MCP connection and
skills load. The `open-canvas` skill starts the bundled local Agent and opens
the SupDance Canvas. The Agent uses a short-lived, single-use handoff to attach
the website to the local connection. It includes both one-use ticket SSE and a
constrained legacy SSE fallback for the currently deployed SupDance website.

Canvas operations are performed only when requested. Image, video, and audio
generation use the connected SupDance account and are subject to its costs and
limits.
